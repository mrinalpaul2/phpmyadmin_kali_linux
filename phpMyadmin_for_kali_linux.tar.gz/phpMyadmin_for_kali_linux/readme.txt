# dpkg -i *.deb
# echo -e "\nInclude /etc/phpmyadmin/apache.conf" >> /etc/apache2/apache2.conf 
# service apache2 restart 
now go to browser and write in the url bar
	localhost/phpmyadmin